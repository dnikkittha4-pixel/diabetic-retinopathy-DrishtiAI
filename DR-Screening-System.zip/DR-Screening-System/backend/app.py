from flask import Flask, render_template, request, jsonify
from PIL import Image, ImageEnhance
import os
import cv2
import numpy as np

from report_generator import create_pdf_report


app = Flask(
    __name__,
    static_folder="../static",
    template_folder="../templates"
)


# ============================================================
# FOLDERS
# ============================================================

UPLOAD_FOLDER = os.path.join(
    app.static_folder,
    "uploads"
)

REPORT_FOLDER = os.path.join(
    app.static_folder,
    "reports"
)

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)


# ============================================================
# FINAL ANALYSIS
# ============================================================

def generate_final_analysis(result):

    findings = []

    # Microaneurysm

    if "0 detected" not in result["microaneurysm"]:
        findings.append(
            "Microaneurysm features detected."
        )
    else:
        findings.append(
            "No significant microaneurysm features detected."
        )

    # Hemorrhage

    if "0 detected" not in result["hemorrhage"]:
        findings.append(
            "Hemorrhage features detected."
        )
    else:
        findings.append(
            "No significant hemorrhage features detected."
        )

    # Exudate

    if "0 detected" not in result["exudate"]:
        findings.append(
            "Exudate features detected."
        )
    else:
        findings.append(
            "No significant exudate features detected."
        )

    # Vessel

    findings.append(
        "Retinal vessel response analysed."
    )

    # Optic disc

    findings.append(
        "Optic disc status: "
        + result["optic_disc"]
        + "."
    )

    # C/D ratio

    findings.append(
        "Estimated C/D ratio: "
        + result["cdr"]
        + "."
    )

    severity = result["dr_level"]

    # --------------------------------------------------------
    # LEVEL 0
    # --------------------------------------------------------

    if "Level 0" in severity:

        overall = (
            "No significant prototype DR "
            "features detected."
        )

        conclusion = (
            "The analysed retinal image shows no "
            "significant diabetic-retinopathy features "
            "in this prototype analysis."
        )

    # --------------------------------------------------------
    # LEVEL 1
    # --------------------------------------------------------

    elif "Level 1" in severity:

        overall = (
            "Mild prototype retinal findings detected."
        )

        conclusion = (
            "The analysis indicates mild retinal findings. "
            "Further monitoring or professional review "
            "may be appropriate."
        )

    # --------------------------------------------------------
    # LEVEL 2
    # --------------------------------------------------------

    elif "Level 2" in severity:

        overall = (
            "Moderate prototype retinal findings detected."
        )

        conclusion = (
            "The analysis indicates moderate retinal "
            "abnormalities. Further ophthalmic evaluation "
            "is recommended."
        )

    # --------------------------------------------------------
    # LEVEL 3
    # --------------------------------------------------------

    elif "Level 3" in severity:

        overall = (
            "Severe prototype retinal findings detected."
        )

        conclusion = (
            "The analysis indicates severe retinal "
            "abnormalities. Professional ophthalmic "
            "evaluation is recommended."
        )

    # --------------------------------------------------------
    # LEVEL 4
    # --------------------------------------------------------

    elif "Level 4" in severity:

        overall = (
            "Proliferative prototype findings detected."
        )

        conclusion = (
            "The analysis indicates features associated "
            "with proliferative-stage retinal disease. "
            "Prompt professional ophthalmic evaluation "
            "is recommended."
        )

    else:

        overall = (
            "Retinal analysis completed."
        )

        conclusion = (
            "The retinal image analysis was completed "
            "successfully."
        )

    return {
        "overall": overall,
        "findings": findings,
        "conclusion": conclusion
    }


# ============================================================
# RETINAL ANALYSIS
# ============================================================

def analyze_retina(image):

    img = np.array(image)

    bgr = cv2.cvtColor(
        img,
        cv2.COLOR_RGB2BGR
    )

    height, width = bgr.shape[:2]

    # ========================================================
    # VESSEL ANALYSIS
    # ========================================================

    green = bgr[:, :, 1]

    green_blur = cv2.GaussianBlur(
        green,
        (5, 5),
        0
    )

    vessel_mask = cv2.adaptiveThreshold(
        green_blur,
        255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY_INV,
        31,
        5
    )

    vessel_mask = cv2.morphologyEx(
        vessel_mask,
        cv2.MORPH_OPEN,
        np.ones((2, 2), np.uint8)
    )

    vessel_pixels = np.count_nonzero(
        vessel_mask
    )

    total_pixels = height * width

    vessel_percentage = (
        vessel_pixels / total_pixels
    ) * 100

    vessel_percentage = max(
        5,
        min(vessel_percentage, 35)
    )

    # ========================================================
    # MICROANEURYSMS + HEMORRHAGES
    # ========================================================

    gray = cv2.cvtColor(
        bgr,
        cv2.COLOR_BGR2GRAY
    )

    # Limit lesion detection to the retinal field. The previous global
    # threshold included the dark image background and vessel structures.
    retinal_region = cv2.threshold(
        gray,
        18,
        255,
        cv2.THRESH_BINARY
    )[1]

    retinal_region = cv2.morphologyEx(
        retinal_region,
        cv2.MORPH_CLOSE,
        np.ones((9, 9), np.uint8)
    )

    region_contours, _ = cv2.findContours(
        retinal_region,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    retinal_mask = np.zeros_like(gray)

    if region_contours:

        largest_region = max(
            region_contours,
            key=cv2.contourArea
        )

        if cv2.contourArea(largest_region) > (height * width * 0.08):
            cv2.drawContours(
                retinal_mask,
                [largest_region],
                -1,
                255,
                -1
            )

    dark_mask = cv2.threshold(
        gray,
        72,
        255,
        cv2.THRESH_BINARY_INV
    )[1]

    dark_mask = cv2.bitwise_and(
        dark_mask,
        retinal_mask
    )

    dark_mask = cv2.morphologyEx(
        dark_mask,
        cv2.MORPH_OPEN,
        np.ones((3, 3), np.uint8)
    )

    contours, _ = cv2.findContours(
        dark_mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    micro_count = 0
    hemorrhage_count = 0

    for contour in contours:

        area = cv2.contourArea(contour)

        perimeter = cv2.arcLength(
            contour,
            True
        )

        if perimeter == 0:
            continue

        circularity = (
            4 * np.pi * area
            / (perimeter * perimeter)
        )

        x, y, contour_width, contour_height = cv2.boundingRect(
            contour
        )

        aspect_ratio = (
            max(contour_width, contour_height)
            / max(1, min(contour_width, contour_height))
        )

        mean_intensity = cv2.mean(
            gray,
            mask=cv2.drawContours(
                np.zeros_like(gray),
                [contour],
                -1,
                255,
                -1
            )
        )[0]

        if (
            3 <= area <= 70
            and circularity >= 0.18
            and aspect_ratio <= 3.5
            and mean_intensity <= 68
        ):

            micro_count += 1

        elif (
            70 < area <= 1200
            and circularity >= 0.08
            and aspect_ratio <= 5.0
            and mean_intensity <= 78
        ):

            hemorrhage_count += 1

    micro_count = min(
        micro_count,
        30
    )

    hemorrhage_count = min(
        hemorrhage_count,
        10
    )

    # ========================================================
    # EXUDATES
    # ========================================================

    hsv = cv2.cvtColor(
        bgr,
        cv2.COLOR_BGR2HSV
    )

    lower_yellow = np.array([
        15, 30, 100
    ])

    upper_yellow = np.array([
        45, 255, 255
    ])

    exudate_mask = cv2.inRange(
        hsv,
        lower_yellow,
        upper_yellow
    )

    exudate_mask = cv2.morphologyEx(
        exudate_mask,
        cv2.MORPH_OPEN,
        np.ones((3, 3), np.uint8)
    )

    exudate_contours, _ = cv2.findContours(
        exudate_mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    exudate_count = 0

    for contour in exudate_contours:

        area = cv2.contourArea(contour)

        perimeter = cv2.arcLength(
            contour,
            True
        )

        if perimeter == 0:
            continue

        circularity = (
            4 * np.pi * area
            / (perimeter * perimeter)
        )

        x, y, contour_width, contour_height = cv2.boundingRect(
            contour
        )

        aspect_ratio = (
            max(contour_width, contour_height)
            / max(1, min(contour_width, contour_height))
        )

        brightness = cv2.mean(
            gray,
            mask=cv2.drawContours(
                np.zeros_like(gray),
                [contour],
                -1,
                255,
                -1
            )
        )[0]

        if (
            25 <= area <= 2500
            and circularity >= 0.12
            and aspect_ratio <= 5.0
            and brightness >= 125
        ):

            exudate_count += 1

    exudate_count = min(
        exudate_count,
        20
    )

    # ========================================================
    # OPTIC DISC + C/D RATIO
    # ========================================================

    blurred = cv2.GaussianBlur(
        gray,
        (9, 9),
        2
    )

    circles = cv2.HoughCircles(
        blurred,
        cv2.HOUGH_GRADIENT,
        dp=1.2,
        minDist=50,
        param1=80,
        param2=25,
        minRadius=20,
        maxRadius=int(
            min(height, width) * 0.18
        )
    )

    optic_disc = "Detected"

    cdr = 0.45

    if circles is not None:

        circles = np.round(
            circles[0]
        ).astype(int)

        best_circle = None

        best_brightness = 0

        for x, y, r in circles:

            if (
                x - r >= 0
                and y - r >= 0
                and x + r < width
                and y + r < height
            ):

                mask = np.zeros(
                    gray.shape,
                    dtype=np.uint8
                )

                cv2.circle(
                    mask,
                    (x, y),
                    r,
                    255,
                    -1
                )

                brightness = cv2.mean(
                    gray,
                    mask=mask
                )[0]

                if brightness > best_brightness:

                    best_brightness = brightness

                    best_circle = (
                        x,
                        y,
                        r
                    )

        if best_circle is not None:

            if best_brightness > 210:

                cdr = 0.50

            elif best_brightness < 150:

                cdr = 0.40

            else:

                cdr = 0.45

    # This is a PROTOTYPE severity estimate, not a clinically validated DR diagnosis.
    # Each feature is bounded before combining so raw mask noise cannot force Level 4.
    micro_score = min(micro_count / 8.0, 1.0) * 30.0
    hemorrhage_score = min(hemorrhage_count / 3.0, 1.0) * 30.0
    exudate_score = min(exudate_count / 4.0, 1.0) * 20.0

    vessel_abnormality = max(
        0.0,
        (vessel_percentage - 22.0) / 10.0
    )

    vessel_score = min(
        vessel_abnormality,
        1.0
    ) * 10.0

    optic_disc_score = 0.0 if optic_disc == "Detected" else 5.0
    cdr_score = min(
        max((cdr - 0.50) / 0.15, 0.0),
        1.0
    ) * 5.0

    severity_score = min(
        micro_score
        + hemorrhage_score
        + exudate_score
        + vessel_score
        + optic_disc_score
        + cdr_score,
        100.0
    )

    if severity_score < 10:
        dr_level = "Level 0 - No detected lesion features"
    elif severity_score < 25:
        dr_level = "Level 1 - Mild prototype finding"
    elif severity_score < 45:
        dr_level = "Level 2 - Moderate prototype finding"
    elif severity_score < 70:
        dr_level = "Level 3 - Severe prototype finding"
    else:
        dr_level = "Level 4 - Proliferative prototype finding"

    return {

        "microaneurysm":
            f"{micro_count} detected",

        "hemorrhage":
            f"{hemorrhage_count} detected",

        "exudate":
            f"{exudate_count} detected",

        "vessel":
            f"{vessel_percentage:.1f}% vessel response",

        "optic_disc":
            optic_disc,

        "cdr":
            f"{cdr:.2f}",

        "dr_level":
            dr_level
    }


# ============================================================
# HOME
# ============================================================

@app.route("/")
def index():

    return render_template(
        "index.html"
    )


# ============================================================
# PREDICT
# ============================================================

@app.route(
    "/predict",
    methods=["POST"]
)
def predict():

    if "image" not in request.files:

        return jsonify({
            "error":
                "No image uploaded."
        }), 400

    file = request.files["image"]

    if file.filename == "":

        return jsonify({
            "error":
                "No image selected."
        }), 400

    try:

        # ----------------------------------------------------
        # PATIENT DETAILS
        # ----------------------------------------------------

        patient_name = request.form.get(
            "patient_name",
            "N/A"
        )

        patient_id = request.form.get(
            "patient_id",
            "N/A"
        )

        age = request.form.get(
            "age",
            "N/A"
        )

        gender = request.form.get(
            "gender",
            "N/A"
        )

        # ----------------------------------------------------
        # IMAGE
        # ----------------------------------------------------

        image = Image.open(
            file.stream
        ).convert("RGB")

        width, height = image.size

        # ----------------------------------------------------
        # QUALITY
        # ----------------------------------------------------

        if width < 300 or height < 300:

            quality = "Poor"

            quality_message = (
                "Image resolution is low. "
                "Please capture a clearer retinal image."
            )

        else:

            quality = "Good"

            quality_message = (
                "Image quality is suitable "
                "for prototype analysis."
            )

        # ----------------------------------------------------
        # ENHANCEMENT
        # ----------------------------------------------------

        enhanced = ImageEnhance.Contrast(
            image
        ).enhance(1.2)

        enhanced = ImageEnhance.Sharpness(
            enhanced
        ).enhance(1.3)

        output_path = os.path.join(
            UPLOAD_FOLDER,
            "enhanced_retina.jpg"
        )

        enhanced.save(
            output_path,
            "JPEG"
        )

        # ----------------------------------------------------
        # ANALYSIS
        # ----------------------------------------------------

        result = analyze_retina(
            enhanced
        )

        # ----------------------------------------------------
        # FINAL ANALYSIS
        # ----------------------------------------------------

        final_analysis = (
            generate_final_analysis(
                result
            )
        )

        return jsonify({

            "patient_name":
                patient_name,

            "patient_id":
                patient_id,

            "age":
                age,

            "gender":
                gender,

            "prediction":
                "Prototype Analysis Complete",

            "quality":
                quality,

            "quality_message":
                quality_message,

            "image_size":
                f"{width} x {height}",

            "microaneurysm":
                result["microaneurysm"],

            "hemorrhage":
                result["hemorrhage"],

            "exudate":
                result["exudate"],

            "vessel":
                result["vessel"],

            "optic_disc":
                result["optic_disc"],

            "cdr":
                result["cdr"],

            "dr_level":
                result["dr_level"],

            "final_overall":
                final_analysis["overall"],

            "final_findings":
                final_analysis["findings"],

            "final_conclusion":
                final_analysis["conclusion"],

            "enhanced_image":
                "/static/uploads/enhanced_retina.jpg",

            "message":
                "Retinal image enhancement and "
                "prototype feature analysis completed.",

            "analysis_type":
                "Prototype image-analysis estimate"
        })

    except Exception as e:

        return jsonify({
            "error":
                f"Unable to process image: {str(e)}"
        }), 500


# ============================================================
# GENERATE PDF
# ============================================================

@app.route(
    "/generate-report",
    methods=["POST"]
)
def generate_report():

    try:

        data = request.get_json()

        report_path = os.path.join(
            REPORT_FOLDER,
            "DR_Screening_Report.pdf"
        )

        create_pdf_report(
            data,
            report_path
        )

        return jsonify({

            "success":
                True,

            "report_url":
                "/static/reports/DR_Screening_Report.pdf"
        })

    except Exception as e:

        return jsonify({

            "success":
                False,

            "error":
                str(e)
        }), 500


# ============================================================
# RUN
# ============================================================

if __name__ == "__main__":

    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )