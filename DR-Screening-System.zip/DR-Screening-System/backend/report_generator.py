from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.units import inch
from datetime import datetime


def create_pdf_report(data, output_path):

    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=40,
        leftMargin=40,
        topMargin=40,
        bottomMargin=40
    )

    styles = getSampleStyleSheet()

    title_style = ParagraphStyle(
        "ReportTitle",
        parent=styles["Title"],
        alignment=TA_CENTER,
        fontSize=20,
        textColor=colors.HexColor("#12355B"),
        spaceAfter=20
    )

    heading_style = ParagraphStyle(
        "Heading",
        parent=styles["Heading2"],
        fontSize=14,
        textColor=colors.HexColor("#087E8B"),
        spaceBefore=15,
        spaceAfter=8
    )

    body_style = ParagraphStyle(
        "Body",
        parent=styles["BodyText"],
        fontSize=10,
        leading=15
    )

    story = []

    # --------------------------------------------------
    # TITLE
    # --------------------------------------------------

    story.append(
        Paragraph(
            "DIABETIC RETINOPATHY SCREENING REPORT",
            title_style
        )
    )

    story.append(
        Paragraph(
            "AI-Based Retinal Image Analysis Prototype",
            body_style
        )
    )

    story.append(Spacer(1, 15))

    # --------------------------------------------------
    # PATIENT DETAILS
    # --------------------------------------------------

    story.append(
        Paragraph(
            "1. Patient Information",
            heading_style
        )
    )

    patient_table = [
        ["Patient Name", data.get("patient_name", "N/A")],
        ["Patient ID", data.get("patient_id", "N/A")],
        ["Age", data.get("age", "N/A")],
        ["Gender", data.get("gender", "N/A")],
        [
            "Report Date",
            datetime.now().strftime("%d-%m-%Y")
        ]
    ]

    table = Table(
        patient_table,
        colWidths=[2.2 * inch, 3.8 * inch]
    )

    table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (0, -1),
             colors.HexColor("#E8F4F8")),
            ("GRID", (0, 0), (-1, -1),
             0.5, colors.grey),
            ("PADDING", (0, 0), (-1, -1), 8),
            ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold")
        ])
    )

    story.append(table)

    # --------------------------------------------------
    # IMAGE INFORMATION
    # --------------------------------------------------

    story.append(
        Paragraph(
            "2. Image Information",
            heading_style
        )
    )

    image_table = [
        ["Parameter", "Result"],
        ["Image Quality", data.get("quality", "N/A")],
        ["Image Size", data.get("image_size", "N/A")]
    ]

    table = Table(
        image_table,
        colWidths=[2.2 * inch, 3.8 * inch]
    )

    table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0),
             colors.HexColor("#12355B")),
            ("TEXTCOLOR", (0, 0), (-1, 0),
             colors.white),
            ("GRID", (0, 0), (-1, -1),
             0.5, colors.grey),
            ("PADDING", (0, 0), (-1, -1), 8)
        ])
    )

    story.append(table)

    # --------------------------------------------------
    # RETINAL ANALYSIS
    # --------------------------------------------------

    story.append(
        Paragraph(
            "3. Retinal Feature Analysis",
            heading_style
        )
    )

    feature_table = [
        ["Feature", "Detected Result"],
        [
            "Microaneurysms",
            data.get("microaneurysm", "N/A")
        ],
        [
            "Hemorrhages",
            data.get("hemorrhage", "N/A")
        ],
        [
            "Exudates",
            data.get("exudate", "N/A")
        ],
        [
            "Vessel Analysis",
            data.get("vessel", "N/A")
        ],
        [
            "Optic Disc",
            data.get("optic_disc", "N/A")
        ],
        [
            "C/D Ratio",
            data.get("cdr", "N/A")
        ]
    ]

    table = Table(
        feature_table,
        colWidths=[2.2 * inch, 3.8 * inch]
    )

    table.setStyle(
        TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0),
             colors.HexColor("#087E8B")),
            ("TEXTCOLOR", (0, 0), (-1, 0),
             colors.white),
            ("GRID", (0, 0), (-1, -1),
             0.5, colors.grey),
            ("PADDING", (0, 0), (-1, -1), 8)
        ])
    )

    story.append(table)

    # --------------------------------------------------
    # DR SEVERITY
    # --------------------------------------------------

    story.append(
        Paragraph(
            "4. DR Severity Assessment",
            heading_style
        )
    )

    story.append(
        Paragraph(
            "<b>Detected Severity:</b> "
            + str(data.get("dr_level", "N/A")),
            body_style
        )
    )

    # --------------------------------------------------
    # FINAL ANALYSIS
    # --------------------------------------------------

    story.append(
        Paragraph(
            "5. Final Analysis",
            heading_style
        )
    )

    story.append(
        Paragraph(
            "<b>Overall Finding:</b><br/>"
            + str(data.get("final_overall", "N/A")),
            body_style
        )
    )

    story.append(Spacer(1, 8))

    findings = data.get("final_findings", [])

    for finding in findings:

        story.append(
            Paragraph(
                "• " + str(finding),
                body_style
            )
        )

    # --------------------------------------------------
    # CONCLUSION
    # --------------------------------------------------

    story.append(
        Paragraph(
            "6. Final Conclusion",
            heading_style
        )
    )

    story.append(
        Paragraph(
            str(
                data.get(
                    "final_conclusion",
                    "N/A"
                )
            ),
            body_style
        )
    )

    story.append(Spacer(1, 20))

    # --------------------------------------------------
    # DISCLAIMER
    # --------------------------------------------------

    story.append(
        Paragraph(
            "<b>Research Prototype Notice:</b> "
            "This report is generated by a prototype retinal "
            "image-analysis system. It is intended for research "
            "and demonstration purposes and is not a clinical "
            "diagnosis. Professional ophthalmic assessment "
            "should be used for clinical decisions.",
            body_style
        )
    )

    doc.build(story)