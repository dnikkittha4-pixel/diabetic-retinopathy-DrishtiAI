const form =
    document.getElementById("screening-form");


const imageInput =
    document.getElementById("retina-image");


const preview =
    document.getElementById("original-preview");


const previewText =
    document.getElementById("preview-text");


const analyzeBtn =
    document.getElementById("analyze-btn");


function setText(element, value) {

    if (element) {

        element.textContent =
            value ?? "—";

    }

}


// ============================================================
// IMAGE PREVIEW
// ============================================================

if (imageInput) {

    imageInput.addEventListener(
        "change",
        function () {

            const file =
                this.files[0];

            if (!file) {

                if (preview) {
                    preview.src = "";
                }

                if (previewText) {
                    previewText.textContent =
                        "Upload retinal image";
                }

                return;
            }


            const imageURL =
                URL.createObjectURL(file);


            if (preview) {

                preview.src =
                    imageURL;

                preview.style.display =
                    "block";
            }


            if (previewText) {

                previewText.style.display =
                    "none";
            }

        }
    );

}


// ============================================================
// FORM SUBMIT
// ============================================================

if (form) {

    form.addEventListener(
        "submit",
        async function (event) {

            event.preventDefault();


            const file =
                imageInput.files[0];


            if (!file) {

                alert(
                    "Please upload a retinal image."
                );

                return;
            }


            // Patient details

            const patientName =
                document.getElementById(
                    "patient-name"
                ).value.trim();


            const patientId =
                document.getElementById(
                    "patient-id"
                ).value.trim();


            const patientAge =
                document.getElementById(
                    "patient-age"
                ).value;


            const patientGender =
                document.getElementById(
                    "patient-gender"
                ).value;


            // FormData

            const formData =
                new FormData();


            formData.append(
                "image",
                file
            );


            formData.append(
                "patient_name",
                patientName
            );


            formData.append(
                "patient_id",
                patientId
            );


            formData.append(
                "age",
                patientAge
            );


            formData.append(
                "gender",
                patientGender
            );


            // Button state

            if (analyzeBtn) {

                analyzeBtn.disabled =
                    true;

                analyzeBtn.textContent =
                    "⏳ Analyzing...";
            }


            try {

                const response =
                    await fetch(
                        "/predict",
                        {
                            method: "POST",
                            body: formData
                        }
                    );


                const data =
                    await response.json();


                if (!response.ok) {

                    throw new Error(
                        data.error ||
                        "Analysis failed."
                    );
                }


                // =================================================
                // BASIC RESULTS
                // =================================================

                setText(
                    document.getElementById(
                        "quality"
                    ),
                    data.quality
                );


                setText(
                    document.getElementById(
                        "image-size"
                    ),
                    data.image_size
                );


                setText(
                    document.getElementById(
                        "microaneurysm"
                    ),
                    data.microaneurysm
                );


                setText(
                    document.getElementById(
                        "hemorrhage"
                    ),
                    data.hemorrhage
                );


                setText(
                    document.getElementById(
                        "exudate"
                    ),
                    data.exudate
                );


                setText(
                    document.getElementById(
                        "vessel"
                    ),
                    data.vessel
                );


                setText(
                    document.getElementById(
                        "optic-disc"
                    ),
                    data.optic_disc
                );


                setText(
                    document.getElementById(
                        "cdr"
                    ),
                    data.cdr
                );


                setText(
                    document.getElementById(
                        "dr-level"
                    ),
                    data.dr_level
                );


                setText(
                    document.getElementById(
                        "prediction"
                    ),
                    data.prediction
                );


                // =================================================
                // ENHANCED IMAGE
                // =================================================

                const enhancedImage =
                    document.getElementById(
                        "enhanced-image"
                    );


                if (enhancedImage) {

                    enhancedImage.src =
                        data.enhanced_image +
                        "?t=" +
                        Date.now();

                    enhancedImage.style.display =
                        "block";
                }


                // =================================================
                // FINAL ANALYSIS
                // =================================================

                setText(
                    document.getElementById(
                        "final-overall"
                    ),
                    data.final_overall
                );


                const findingsList =
                    document.getElementById(
                        "final-findings"
                    );


                if (findingsList) {

                    findingsList.innerHTML =
                        "";


                    data.final_findings.forEach(
                        function (finding) {

                            const li =
                                document.createElement(
                                    "li"
                                );

                            li.textContent =
                                "✓ " + finding;

                            findingsList.appendChild(
                                li
                            );

                        }
                    );

                }


                setText(
                    document.getElementById(
                        "final-conclusion"
                    ),
                    data.final_conclusion
                );


                setText(
                    document.getElementById(
                        "message"
                    ),
                    data.message
                );


                // Scroll to results

                document.getElementById(
                    "results"
                ).scrollIntoView({
                    behavior: "smooth"
                });


            } catch (error) {

                alert(
                    error.message
                );

            } finally {

                if (analyzeBtn) {

                    analyzeBtn.disabled =
                        false;

                    analyzeBtn.textContent =
                        "🔬 Analyze Retina";
                }

            }

        }
    );

}


// ============================================================
// PDF REPORT
// ============================================================

const reportBtn =
    document.getElementById(
        "report-btn"
    );


if (reportBtn) {

    reportBtn.addEventListener(
        "click",
        async function () {

            // Collect current results

            const data = {

                patient_name:
                    document.getElementById(
                        "patient-name"
                    )?.value || "N/A",

                patient_id:
                    document.getElementById(
                        "patient-id"
                    )?.value || "N/A",

                age:
                    document.getElementById(
                        "patient-age"
                    )?.value || "N/A",

                gender:
                    document.getElementById(
                        "patient-gender"
                    )?.value || "N/A",

                quality:
                    document.getElementById(
                        "quality"
                    )?.textContent || "N/A",

                image_size:
                    document.getElementById(
                        "image-size"
                    )?.textContent || "N/A",

                microaneurysm:
                    document.getElementById(
                        "microaneurysm"
                    )?.textContent || "N/A",

                hemorrhage:
                    document.getElementById(
                        "hemorrhage"
                    )?.textContent || "N/A",

                exudate:
                    document.getElementById(
                        "exudate"
                    )?.textContent || "N/A",

                vessel:
                    document.getElementById(
                        "vessel"
                    )?.textContent || "N/A",

                optic_disc:
                    document.getElementById(
                        "optic-disc"
                    )?.textContent || "N/A",

                cdr:
                    document.getElementById(
                        "cdr"
                    )?.textContent || "N/A",

                dr_level:
                    document.getElementById(
                        "dr-level"
                    )?.textContent || "N/A",

                final_overall:
                    document.getElementById(
                        "final-overall"
                    )?.textContent || "N/A",

                final_conclusion:
                    document.getElementById(
                        "final-conclusion"
                    )?.textContent || "N/A",

                final_findings:
                    Array.from(
                        document.querySelectorAll(
                            "#final-findings li"
                        )
                    ).map(
                        li => li.textContent
                    )
            };


            // Make sure analysis exists

            if (
                data.quality === "N/A" ||
                data.dr_level === "N/A"
            ) {

                alert(
                    "Please analyze a retinal image first."
                );

                return;
            }


            reportBtn.disabled =
                true;

            reportBtn.textContent =
                "⏳ Generating Report...";


            try {

                const response =
                    await fetch(
                        "/generate-report",
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body:
                                JSON.stringify(data)
                        }
                    );


                const result =
                    await response.json();


                if (!result.success) {

                    throw new Error(
                        result.error ||
                        "Report generation failed."
                    );
                }


                // Open PDF

                window.open(
                    result.report_url +
                    "?t=" +
                    Date.now(),
                    "_blank"
                );


            } catch (error) {

                alert(
                    "Unable to generate report: " +
                    error.message
                );

            } finally {

                reportBtn.disabled =
                    false;

                reportBtn.textContent =
                    "📄 Generate PDF Report";
            }

        }
    );

}